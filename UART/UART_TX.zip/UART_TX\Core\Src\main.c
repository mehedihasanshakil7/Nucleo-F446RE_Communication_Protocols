//#define RCC_BASE (0x40023800)
//#define GPIOA_BASE (0x40020000)
//#define UART2_BASE (0x40004400)
//
//#define RCC_AHB1ENR (*(volatile unsigned int *)(RCC_BASE + 0x30))
//#define RCC_APB1ENR (*(volatile unsigned int *)(RCC_BASE + 0x40))
//
//#define GPIOA_MODER (*(volatile unsigned int *)(GPIOA_BASE + 0x00))
//#define GPIOA_AFRL (*(volatile unsigned int *)(GPIOA_BASE + 0x20))
//
//#define UART2_SR (*(volatile unsigned int *)(UART2_BASE + 0x00))
//#define UART2_BRR (*(volatile unsigned int *)(UART2_BASE + 0x08))
//#define UART2_CR1 (*(volatile unsigned int *)(UART2_BASE + 0x0C))
//#define UART2_DR (*(volatile unsigned int *)(UART2_BASE + 0x04))
//
//#define SYSCLK 16000000U
//#define BAUDRATE 9600U
//
//void uart2_tx_init(void);
//void uart2_send(char ch);
//char uart2_receive(void);
//
//int main(void) {
//	uart2_tx_init();
//	while(1) {
//		uart2_send('A');               // Send a character
//		char ch = uart2_receive();     // Wait and receive it
//		(void)ch;
//	}
//}
//
//void uart2_tx_init() {
//	/* Enable clock of port A*/
//	RCC_AHB1ENR |= (1<<0);
//
//	/*PA2 to alternate function mode 10 at bit 4 and 5*/
//	GPIOA_MODER &= ~(3 << 4);  // Clear bits 5:4
//	GPIOA_MODER |= (2 << 4);  // Set to Alternate Function mode (10)
//
//	/*AF7 (0111)*/
//	GPIOA_AFRL &= ~(0xF<<8); //clear bit 8-11
//	GPIOA_AFRL |= (7<<8);
//
//	/*PA3 to alternate function mode 10 at bit 6 and 7*/
//	GPIOA_MODER &= ~(3 << 6);  // Clear bits 6:7
//	GPIOA_MODER |=  (2 << 6);  // Set to Alternate Function mode (10)
//
//	/*AF7 (0111)*/
//	GPIOA_AFRL &= ~(0xF<<12); //clear bit 12-15
//	GPIOA_AFRL |= (7<<12);
//
//	/*Clock of USART2*/
//	RCC_APB1ENR |= (1<<17);
//
//	/*Configure BaudRate*/
//	UART2_BRR = (SYSCLK + (BAUDRATE / 2)) / BAUDRATE;
//
//	/* Enable TE*/
//	//UART2_CR1 = (1<<3); // Directly assigned
//	UART2_CR1 = (1 << 2) | (1 << 3);
//
//	/*Enable the UART2*/
//	UART2_CR1 |= (1<<13);
//}
//
//void uart2_send(char ch) {
//	/* Tx data register is empty*/
//	while(!(UART2_SR & (1<<6))) {}
//
//	UART2_DR = (ch & 0xFF);
//}
//
//char uart2_receive(void) {
//	/* Rx data register is empty*/
//	while(!(UART2_SR & (1<<6))) {}
//	volatile char rcv = (UART2_DR & 0xFF);
//	return rcv;
//}


#define RCC_BASE (0x40023800)
#define GPIOA_BASE (0x40020000)
#define UART1_BASE (0x40011000)

#define RCC_AHB1ENR (*(volatile unsigned int *)(RCC_BASE + 0x30))
#define RCC_APB2ENR (*(volatile unsigned int *)(RCC_BASE + 0x44))

#define GPIOA_MODER (*(volatile unsigned int *)(GPIOA_BASE + 0x00))
#define GPIOA_AFRH (*(volatile unsigned int *)(GPIOA_BASE + 0x24))

#define UART1_SR (*(volatile unsigned int *)(UART1_BASE + 0x00))
#define UART1_BRR (*(volatile unsigned int *)(UART1_BASE + 0x08))
#define UART1_CR1 (*(volatile unsigned int *)(UART1_BASE + 0x0C))
#define UART1_DR (*(volatile unsigned int *)(UART1_BASE + 0x04))

#define SYSCLK 16000000U
#define BAUDRATE 9600U

void uart1_tx_init(void);
void uart1_send(int n, char* str);

int main(void) {
	uart1_tx_init();
	while(1) {
		uart1_send(6, "Shakil");
	}
}

void uart1_tx_init() {
	/* Enable clock of port A*/
	RCC_AHB1ENR |= (1<<0);

	/*PA9 to alternate function mode 10 at bit 18 and 19*/
	GPIOA_MODER &= ~(3 << 18);  // Clear bits 18:19
	GPIOA_MODER |= (2 << 18);  // Set to Alternate Function mode (10)

	/*AF7 (0111)*/
	GPIOA_AFRH &= ~(0xF<<4); //clear bit 4-7
	GPIOA_AFRH |= (7<<4);

	/*Clock of USART1*/
	RCC_APB2ENR |= (1<<4);

	/*Configure BaudRate*/
	UART1_BRR = (SYSCLK + (BAUDRATE / 2)) / BAUDRATE;

	/* Enable TE*/
	UART1_CR1 = (1<<3); // Directly assigned, intentionally cleared other bits

	/*Enable the UART1*/
	UART1_CR1 |= (1<<13);
}

void uart1_send(int n, char* str) {
	for(int i = 0; i < n; i++) {
		/* Tx data register is empty*/
		while(!(UART1_SR & (1<<7))) {}

		UART1_DR = *str++;
	}
}
